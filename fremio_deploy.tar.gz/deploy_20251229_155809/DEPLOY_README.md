# Fremio Deployment Package

## Files Included:
- `frontend/` - Built frontend static files
- `backend/` - Backend server files
- `frontend.env.example` - Example frontend environment config
- `backend.env.example` - Example backend environment config

## Deployment Steps:

### 1. Setup Database (PostgreSQL)
```bash
# Create database
createdb fremio

# Import schema
psql -U your_user -d fremio -f backend/database/schema.sql
```

### 2. Configure Environment
```bash
# Backend
cp backend.env.example backend/.env
# Edit backend/.env with your production settings

# Update frontend API URL in nginx config
```

### 3. Install Backend Dependencies
```bash
cd backend
npm install --production
```

### 4. Setup PM2 for Process Management
```bash
npm install -g pm2
cd backend
pm2 start server.js --name fremio-backend
pm2 save
pm2 startup
```

### 5. Configure Nginx
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    
    # Frontend
    location / {
        root /var/www/fremio/frontend;
        try_files $uri $uri/ /index.html;
    }
    
    # Backend API
    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Uploaded files
    location /uploads {
        proxy_pass http://localhost:3000/uploads;
    }
}
```

### 6. Setup SSL with Certbot
```bash
sudo certbot --nginx -d yourdomain.com
```

