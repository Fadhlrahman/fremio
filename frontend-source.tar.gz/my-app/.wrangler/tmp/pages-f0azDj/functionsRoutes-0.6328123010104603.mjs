import { onRequest as ___middleware_js_onRequest } from "/Users/salwa/Documents/FremioNew/fremio/my-app/functions/_middleware.js"

export const routes = [
    {
      routePath: "/",
      mountPath: "/",
      method: "",
      middlewares: [___middleware_js_onRequest],
      modules: [],
    },
  ]