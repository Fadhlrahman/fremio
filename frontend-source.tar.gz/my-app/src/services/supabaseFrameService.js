/**
 * Supabase Frame Service - DEPRECATED
 * Redirect ke frameService.js
 */

// Re-export everything from frameService
export * from './frameService.js';
export { default } from './frameService.js';

// Legacy compatibility
export const isSupabaseConfigured = false;

